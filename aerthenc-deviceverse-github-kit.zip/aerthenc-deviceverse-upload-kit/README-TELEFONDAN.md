# Build the Android APK using GitHub Actions (phone-only guide)

This repo is configured to build a **debug APK** in GitHub Actions. The APK is unsigned for Play Store distribution, but is normally installable on your own Android phone after allowing installation from the browser/files app.

## Important
The workflow expects the project archive to be committed at the repository root with this exact name:
`aerthenc-deviceverse-android.zip`

The archive must contain the `aerthenc-deviceverse/package.json` project folder.

## Phone-only setup
1. Sign in or create an account at https://github.com/ using Chrome on your phone.
2. Create a **new public repository** named `aerthenc-deviceverse-android`. Public repositories allow GitHub Actions standard runners without using private-repository minutes; check GitHub's current limits and terms.
3. Open the new repository, choose **Add file → Upload files**, select `aerthenc-deviceverse-android.zip` from your phone's Downloads folder, and commit it to the `main` branch.
4. In the repository choose **Add file → Create new file**.
5. For the filename, enter exactly `.github/workflows/android.yml` (GitHub will create the folders).
6. Paste the workflow content from `GITHUB-ACTIONS-WORKFLOW.txt` or from the `.github/workflows/android.yml` file in this project, then commit the new file to `main`.
7. Open the **Actions** tab. If asked, enable GitHub Actions. Choose **Build Aerthenc DeviceVerse APK**, then **Run workflow → Run workflow**. A push to the workflow or archive path can also trigger it.
8. Wait for the workflow run to finish with a green check. If it fails, open the failed step and read the error; do not download an APK unless the run succeeded.
9. Open the successful run, find **Artifacts**, and tap `aerthenc-deviceverse-debug-apk` to download the ZIP containing `app-debug.apk`.
10. Extract that downloaded artifact ZIP using My Files. Tap `app-debug.apk` and follow Android's prompts. If blocked, allow **Install unknown apps** for the app used to open the APK, then retry. Only install APKs you built and trust.

## Troubleshooting
- If the workflow does not appear, check the path is exactly `.github/workflows/android.yml` and that the file was committed to `main`.
- If the archive is named differently, either rename it to the exact name above or update the workflow's `unzip` command and push trigger paths.
- If `npm run build` fails, open the log for that step. No APK artifact will be created until the build succeeds.
- GitHub may change UI labels on mobile. Use Chrome's **Desktop site** option if you cannot find Upload files, Actions, or Run workflow.

## Workflow file
The file to create in GitHub is `.github/workflows/android.yml`. Its contents are included in this project at `.github/workflows/android.yml` and in the companion text file `GITHUB-ACTIONS-WORKFLOW.txt`.
