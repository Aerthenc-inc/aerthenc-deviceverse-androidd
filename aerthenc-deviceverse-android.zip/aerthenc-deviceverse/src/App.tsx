import { type CSSProperties, useMemo, useState } from 'react'
import {
  ArrowDownRight, ArrowLeft, ArrowRight, ArrowUpRight, BatteryCharging, Bookmark, Box, Check,
  ChevronDown, ChevronRight, CircleHelp, Cpu, Eye, Filter, Flame, FoldHorizontal,
  Gauge, Grid2X2, Layers3, Menu, Moon, Move3D, Search, Settings2, ShieldCheck, Smartphone,
  Sparkles, Sun, X, Zap,
} from 'lucide-react'
import DeviceViewer from './DeviceViewer'

type Device = {
  id: string; name: string; brand: string; family: string; kind: 'Flagship' | 'Foldable' | 'Concept' | 'Archive'
  year: string; screen: string; chip: string; weight: string; note: string; color: string; status: 'Released' | 'Concept'
}

const devices: Device[] = [
  { id: 's25-ultra', name: 'Galaxy S25 Ultra', brand: 'Samsung', family: 'Galaxy S', kind: 'Flagship', year: '2025', screen: '6.9 in', chip: 'Snapdragon 8 Elite for Galaxy', weight: '218 g', note: 'Titanium · S Pen', color: '#8e93a0', status: 'Released' },
  { id: 'z-fold7', name: 'Galaxy Z Fold7', brand: 'Samsung', family: 'Galaxy Z', kind: 'Foldable', year: '2025', screen: '8.0 in inner', chip: 'Snapdragon 8 Elite for Galaxy', weight: '215 g', note: 'Book-style foldable', color: '#6f83a6', status: 'Released' },
  { id: 'z-flip6', name: 'Galaxy Z Flip6', brand: 'Samsung', family: 'Galaxy Z', kind: 'Foldable', year: '2024', screen: '6.7 in inner', chip: 'Snapdragon 8 Gen 3 for Galaxy', weight: '187 g', note: 'Compact flip design', color: '#8f78bd', status: 'Released' },
  { id: 'iphone-16-pro', name: 'iPhone 16 Pro Max', brand: 'Apple', family: 'iPhone Pro', kind: 'Flagship', year: '2024', screen: '6.9 in', chip: 'A18 Pro', weight: '227 g', note: 'Titanium · Pro camera', color: '#777b84', status: 'Released' },
  { id: 'pixel-9-pro', name: 'Pixel 9 Pro', brand: 'Google', family: 'Pixel', kind: 'Flagship', year: '2024', screen: '6.3 in', chip: 'Google Tensor G4', weight: '199 g', note: 'Computational photography', color: '#a1a6a7', status: 'Released' },
  { id: 'xiaomi-15-ultra', name: 'Xiaomi 15 Ultra', brand: 'Xiaomi', family: 'Ultra', kind: 'Flagship', year: '2025', screen: '6.73 in', chip: 'Snapdragon 8 Elite', weight: '226 g', note: 'Camera-focused flagship', color: '#34373c', status: 'Released' },
  { id: 'oppo-find-n5', name: 'Find N5', brand: 'OPPO', family: 'Find N', kind: 'Foldable', year: '2025', screen: '8.12 in inner', chip: 'Snapdragon 8 Elite', weight: 'Approx. 229 g', note: 'Thin book-style foldable', color: '#c8b9a3', status: 'Released' },
  { id: 'iphone-duo-concept', name: 'iPhone Duo', brand: 'Aerthenc Concept Lab', family: 'Concept series', kind: 'Concept', year: 'Concept', screen: 'Dual-screen concept', chip: 'Not applicable', weight: 'Not announced', note: 'Unofficial concept · not an Apple product', color: '#8a80d2', status: 'Concept' },
  { id: 'lg-wing', name: 'LG Wing', brand: 'LG', family: 'Explorer Project', kind: 'Archive', year: '2020', screen: '6.8 in main', chip: 'Snapdragon 765G', weight: '260 g', note: 'Historical swivel-screen phone', color: '#8d98a1', status: 'Released' },
  { id: 'nothing-phone-2', name: 'Phone (2)', brand: 'Nothing', family: 'Phone', kind: 'Flagship', year: '2023', screen: '6.7 in', chip: 'Snapdragon 8+ Gen 1', weight: '201 g', note: 'Transparent-inspired design', color: '#aab2bc', status: 'Released' },
  { id: 'oneplus-13', name: 'OnePlus 13', brand: 'OnePlus', family: 'Number series', kind: 'Flagship', year: '2025', screen: '6.82 in', chip: 'Snapdragon 8 Elite', weight: 'Approx. 210 g', note: 'Performance-focused flagship', color: '#8e93a0', status: 'Released' },
  { id: 'huawei-pura-70-ultra', name: 'Pura 70 Ultra', brand: 'Huawei', family: 'Pura', kind: 'Flagship', year: '2024', screen: '6.8 in', chip: 'Kirin 9010', weight: '226 g', note: 'Retractable camera system', color: '#a8a18e', status: 'Released' },
  { id: 'honor-magic7-pro', name: 'Magic7 Pro', brand: 'HONOR', family: 'Magic', kind: 'Flagship', year: '2024', screen: '6.8 in', chip: 'Snapdragon 8 Elite', weight: 'Approx. 223 g', note: 'AI-focused flagship', color: '#8796af', status: 'Released' },
  { id: 'vivo-x200-pro', name: 'X200 Pro', brand: 'vivo', family: 'X series', kind: 'Flagship', year: '2024', screen: '6.78 in', chip: 'MediaTek Dimensity 9400', weight: 'Approx. 228 g', note: 'Zeiss camera collaboration', color: '#7e8792', status: 'Released' },
  { id: 'motorola-razr-60-ultra', name: 'razr 60 ultra', brand: 'Motorola', family: 'razr', kind: 'Foldable', year: '2025', screen: '7.0 in inner', chip: 'Snapdragon 8 Elite', weight: 'Approx. 199 g', note: 'Clamshell foldable', color: '#7b9578', status: 'Released' },
  { id: 'sony-xperia-1-vi', name: 'Xperia 1 VI', brand: 'Sony', family: 'Xperia', kind: 'Flagship', year: '2024', screen: '6.5 in', chip: 'Snapdragon 8 Gen 3', weight: '192 g', note: 'Creator-focused hardware', color: '#343b45', status: 'Released' },
]

const partOptions = [
  { id: 'frame', title: 'Titanium / frame', text: 'Structural shell and side rails.' },
  { id: 'display', title: 'Display stack', text: 'OLED-like panel representation; not a teardown CAD.' },
  { id: 'camera', title: 'Camera system', text: 'Lens positions are illustrative geometry.' },
  { id: 'battery', title: 'Battery pack', text: 'Energy storage module shown at representative scale.' },
  { id: 'board', title: 'Mainboard + SoC', text: 'Logic board and processor package.' },
  { id: 'cooling', title: 'Vapor chamber', text: 'Representative thermal spreader.' },
  { id: 'coil', title: 'Wireless charging coil', text: 'Inductive charging coil concept.' },
  { id: 'usb', title: 'USB-C module', text: 'Charging port and lower acoustic module.' },
  { id: 'hinge', title: 'Hinge mechanism', text: 'Moving joint assembly for foldable model.' },
]

const osList = [
  { id: 'ios', label: 'iOS Experience', brand: 'Apple-inspired', accent: '#91a9ff', bg: '#11182c' },
  { id: 'oneui', label: 'One UI Experience', brand: 'Samsung-inspired', accent: '#9c8cff', bg: '#171628' },
  { id: 'pixel', label: 'Pixel Experience', brand: 'Material-inspired', accent: '#8ab4f8', bg: '#172327' },
] as const

type OsId = typeof osList[number]['id']
const appIcons = [
  { name: 'Phone', glyph: '☎', color: '#43c987' }, { name: 'Messages', glyph: '●', color: '#3eab7d' },
  { name: 'Camera', glyph: '◉', color: '#596778' }, { name: 'Photos', glyph: '✿', color: '#e7a7c8' },
  { name: 'Browser', glyph: '◎', color: '#76a9f9' }, { name: 'Settings', glyph: '⚙', color: '#8d98aa' },
  { name: 'Music', glyph: '♫', color: '#e77492' }, { name: 'Files', glyph: '▰', color: '#edc46e' },
]

function App() {
  const [theme, setTheme] = useState<'dark' | 'light'>('dark')
  const [selectedDeviceId, setSelectedDeviceId] = useState('s25-ultra')
  const [search, setSearch] = useState('')
  const [brandFilter, setBrandFilter] = useState('All brands')
  const [kindFilter, setKindFilter] = useState('All types')
  const [color, setColor] = useState('#8e93a0')
  const [exploded, setExploded] = useState(false)
  const [xray, setXray] = useState(false)
  const [foldAngle, setFoldAngle] = useState(0)
  const [selectedPart, setSelectedPart] = useState('')
  const [lowQuality, setLowQuality] = useState(false)
  const [activeOS, setActiveOS] = useState<OsId>('ios')
  const [openApp, setOpenApp] = useState('')
  const [controlPanel, setControlPanel] = useState(false)
  const [wifi, setWifi] = useState(true)
  const [airplane, setAirplane] = useState(false)
  const [osDark, setOsDark] = useState(true)
  const [favorites, setFavorites] = useState<string[]>([])
  const [compareIds, setCompareIds] = useState<string[]>(['s25-ultra', 'z-fold7'])
  const [compareInternals, setCompareInternals] = useState(false)
  const [posterOpen, setPosterOpen] = useState(false)
  const [mobileNav, setMobileNav] = useState(false)
  const [onlyConcepts, setOnlyConcepts] = useState(false)

  const selectedDevice = devices.find((d) => d.id === selectedDeviceId) ?? devices[0]
  const foldable = selectedDevice.kind === 'Foldable' || selectedDevice.id.includes('duo')
  const filteredDevices = useMemo(() => devices.filter((d) => {
    const q = search.toLowerCase().trim()
    return (!q || `${d.name} ${d.brand} ${d.family} ${d.chip}`.toLowerCase().includes(q))
      && (brandFilter === 'All brands' || d.brand === brandFilter)
      && (kindFilter === 'All types' || d.kind === kindFilter)
      && (!onlyConcepts || d.kind === 'Concept')
  }), [search, brandFilter, kindFilter, onlyConcepts])
  const compared = compareIds.map((id) => devices.find((d) => d.id === id)).filter((d): d is Device => Boolean(d))
  const activeOSMeta = osList.find((os) => os.id === activeOS) ?? osList[0]

  function chooseDevice(device: Device) {
    setSelectedDeviceId(device.id)
    setColor(device.color)
    setFoldAngle(0)
    setSelectedPart('')
    document.querySelector('#studio')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  function toggleCompare(id: string) {
    setCompareIds((current) => current.includes(id) ? current.filter((item) => item !== id) : current.length < 3 ? [...current, id] : current)
  }

  function toggleFavorite(id: string) {
    setFavorites((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id])
  }

  function scrollTo(id: string) {
    setMobileNav(false)
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  return (
    <div className={`app ${theme}`}>
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />
      <header className="topbar">
        <button className="brand-lockup" onClick={() => scrollTo('home')} aria-label="Aerthenc DeviceVerse home">
          <span className="brand-mark">A<span>.</span></span>
          <span className="brand-text"><b>AERTHENC</b><small>DEVICEVERSE <i>BY AERTHENC INC.</i></small></span>
        </button>
        <nav className={mobileNav ? 'main-nav mobile-open' : 'main-nav'}>
          <button onClick={() => scrollTo('devices')}>Explore Devices</button>
          <button onClick={() => scrollTo('studio')}>3D Studio</button>
          <button onClick={() => scrollTo('inside')}>Inside the Device</button>
          <button onClick={() => scrollTo('playground')}>OS Playground</button>
          <button onClick={() => scrollTo('compare')}>Compare</button>
        </nav>
        <div className="top-actions">
          <button className="icon-button theme-toggle" aria-label="Toggle theme" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>{theme === 'dark' ? <Sun size={17} /> : <Moon size={17} />}</button>
          <button className="header-cta" onClick={() => scrollTo('studio')}>Enter the lab <ArrowUpRight size={15} /></button>
          <button className="icon-button mobile-menu-button" aria-label="Open navigation" onClick={() => setMobileNav(!mobileNav)}>{mobileNav ? <X size={18} /> : <Menu size={18} />}</button>
        </div>
      </header>

      <main>
        <section className="hero section-wrap" id="home">
          <div className="hero-copy">
            <div className="eyebrow"><span className="eyebrow-line" /> THE NEXT DIMENSION OF DEVICES <span className="eyebrow-pill">BETA EXPERIENCE</span></div>
            <h1>Explore every device.<br /><span>Beyond the screen.</span></h1>
            <p className="hero-lede">Step inside the technology you love. Rotate precision-inspired 3D models, unfold tomorrow's form factors, and explore the systems that power your everyday.</p>
            <div className="hero-cta-row">
              <button className="primary-button" onClick={() => scrollTo('studio')}><Move3D size={17} /> Launch 3D Studio <ArrowUpRight size={16} /></button>
              <button className="text-button" onClick={() => scrollTo('devices')}>Browse device index <ArrowDownRight size={17} /></button>
            </div>
            <div className="hero-trust-row">
              <div className="trust-avatars"><span>S</span><span>A</span><span>G</span><span>+</span></div>
              <div><b>One universe. Every form factor.</b><small>Flagships · Foldables · Concepts · Icons</small></div>
            </div>
          </div>
          <div className="hero-visual" aria-label="3D device preview">
            <div className="hero-orbit orbit-a" /><div className="hero-orbit orbit-b" />
            <div className="hero-visual-glow" />
            <div className="hero-phone-stand">
              <div className="hero-phone-side" />
              <div className="hero-phone-back">
                <div className="camera-island"><i /><i /><i /><b /></div>
                <div className="hero-back-shine" />
                <div className="phone-logo">A</div>
              </div>
            </div>
            <div className="visual-chip chip-top"><span className="chip-dot violet" /> PRECISION FORM <b>01 / 06</b></div>
            <div className="visual-chip chip-bottom"><span className="mini-wave">⌁</span><span>Built for exploration<small>Materials · Mechanisms · Systems</small></span><ArrowUpRight size={15} /></div>
            <div className="hero-crosshair">+</div>
          </div>
          <div className="hero-bottom-line"><span>DESIGNED FOR THE CURIOUS</span><span>01 — 06 <i /></span><span>SCROLL TO EXPLORE <ChevronDown size={13} /></span></div>
        </section>

        <section className="metrics section-wrap" aria-label="Platform highlights">
          <div className="metric"><span className="metric-icon"><Box size={17} /></span><div><b>3D first</b><small>Interactive geometry</small></div></div>
          <div className="metric"><span className="metric-icon"><FoldHorizontal size={17} /></span><div><b>Form in motion</b><small>Fold & hinge simulation</small></div></div>
          <div className="metric"><span className="metric-icon"><Layers3 size={17} /></span><div><b>Under the shell</b><small>Component exploration</small></div></div>
          <div className="metric"><span className="metric-icon"><Smartphone size={17} /></span><div><b>OS playground</b><small>Tap-through experiences</small></div></div>
        </section>

        <section className="section-wrap section-block" id="studio">
          <div className="section-heading">
            <div><div className="eyebrow"><span className="eyebrow-line" /> INTERACTIVE WORKSPACE / 01</div><h2>The 3D <span>device studio.</span></h2><p>Turn the hardware around. Inspect the silhouette. Pull the layers apart.</p></div>
            <div className="heading-side-note"><span className="live-dot" /> LIVE RENDER SESSION <small>WebGL · PBR-style materials</small></div>
          </div>
          <div className="studio-layout">
            <div className="studio-viewport-card">
              <div className="viewport-topline"><div className="model-identity"><span className="device-number">DV / {String(devices.findIndex((d) => d.id === selectedDevice.id) + 1).padStart(3, '0')}</span><div><b>{selectedDevice.name}</b><small>{selectedDevice.brand} · {selectedDevice.year === 'Concept' ? 'Unofficial concept' : `${selectedDevice.year} device`}</small></div></div><span className={selectedDevice.status === 'Concept' ? 'status-tag concept' : 'status-tag'}>{selectedDevice.status === 'Concept' ? 'CONCEPT MODEL' : 'REFERENCE MODEL'}</span></div>
              <DeviceViewer deviceId={selectedDevice.id} color={color} exploded={exploded} xray={xray} foldAngle={foldAngle} selectedPart={selectedPart} lowQuality={lowQuality} />
              <div className="viewer-footer"><span><i className="mouse-icon">⌖</i> Click + drag to orbit</span><span>SCENE 01.04 <b>●●●</b></span><button onClick={() => setLowQuality(!lowQuality)}><Gauge size={13} /> {lowQuality ? 'Low power on' : 'Performance'}</button></div>
            </div>
            <aside className="studio-controls">
              <div className="control-card selected-device-card">
                <div className="control-label">SELECTED DEVICE <span>{String(devices.findIndex((d) => d.id === selectedDevice.id) + 1).padStart(2, '0')} / {String(devices.length).padStart(2, '0')}</span></div>
                <h3>{selectedDevice.name}</h3><p>{selectedDevice.note}</p>
                <div className="device-meta"><span><Smartphone size={13} /> {selectedDevice.screen}</span><span><Cpu size={13} /> {selectedDevice.chip.split(' ').slice(0, 3).join(' ')}</span></div>
                <button className="outline-button full-width" onClick={() => scrollTo('devices')}>Change device <ChevronRight size={15} /></button>
              </div>
              <div className="control-card">
                <div className="control-label">MODEL CONTROLS <span>01</span></div>
                <div className="control-action-grid">
                  <button className={exploded ? 'mode-button active' : 'mode-button'} onClick={() => { setExploded(!exploded); if (!exploded) setXray(false) }}><Layers3 size={16} /><span>Exploded view</span><small>{exploded ? 'Expanded' : 'Separate layers'}</small></button>
                  <button className={xray ? 'mode-button active' : 'mode-button'} onClick={() => { setXray(!xray); if (!xray) setExploded(false) }}><Eye size={16} /><span>X-Ray mode</span><small>{xray ? 'Translucent shell' : 'See through shell'}</small></button>
                  <button className="mode-button" onClick={() => { setExploded(false); setXray(false); setFoldAngle(0) }}><Zap size={16} /><span>Assemble</span><small>Reset the model</small></button>
                  <button className="mode-button" onClick={() => setPosterOpen(true)}><Sparkles size={16} /><span>Device poster</span><small>Print-ready view</small></button>
                </div>
                <div className="color-picker-row"><span>Finish</span><div className="swatches"><button aria-label="Titanium finish" className={color === '#8e93a0' ? 'swatch selected' : 'swatch'} style={{ background: '#8e93a0' }} onClick={() => setColor('#8e93a0')} /><button aria-label="Midnight finish" className={color === '#262936' ? 'swatch selected' : 'swatch'} style={{ background: '#262936' }} onClick={() => setColor('#262936')} /><button aria-label="Violet finish" className={color === '#8f78bd' ? 'swatch selected' : 'swatch'} style={{ background: '#8f78bd' }} onClick={() => setColor('#8f78bd')} /><button aria-label="Blue finish" className={color === '#6f83a6' ? 'swatch selected' : 'swatch'} style={{ background: '#6f83a6' }} onClick={() => setColor('#6f83a6')} /><button aria-label="Sand finish" className={color === '#c8b9a3' ? 'swatch selected' : 'swatch'} style={{ background: '#c8b9a3' }} onClick={() => setColor('#c8b9a3')} /></div></div>
                {foldable && <div className="hinge-control"><div className="hinge-control-head"><span><FoldHorizontal size={14} /> Hinge angle</span><b>{foldAngle}°</b></div><input type="range" min="0" max="180" step="5" value={foldAngle} onChange={(e) => setFoldAngle(Number(e.target.value))} /><div className="range-labels"><span>Open</span><span>Half folded</span><span>Closed</span></div><div className="preset-buttons"><button onClick={() => setFoldAngle(0)}>0° Open</button><button onClick={() => setFoldAngle(90)}>90° Flex</button><button onClick={() => setFoldAngle(180)}>180° Closed</button></div></div>}
              </div>
              <div className="studio-tip"><CircleHelp size={15} /><p><b>Model note</b> Geometry is procedurally generated for this demo. It is interactive 3D, but not manufacturer CAD or a verified internal teardown.</p></div>
            </aside>
          </div>
        </section>

        <section className="section-wrap section-block" id="inside">
          <div className="section-heading compact-heading">
            <div><div className="eyebrow"><span className="eyebrow-line" /> HARDWARE EXPLORER / 02</div><h2>What's beneath <span>the surface?</span></h2><p>Choose a component to highlight it in the 3D scene and learn the role it plays.</p></div>
            <button className="text-button" onClick={() => { setExploded(true); setXray(false); scrollTo('studio') }}>Open exploded view <ArrowUpRight size={16} /></button>
          </div>
          <div className="inside-layout">
            <div className="parts-list">
              {partOptions.map((part, index) => <button key={part.id} className={selectedPart === part.id ? 'part-row selected' : 'part-row'} onClick={() => { setSelectedPart(part.id); if (part.id === 'hinge' && !foldable) { const fold = devices.find((d) => d.id === 'z-fold7')!; setSelectedDeviceId(fold.id); setColor(fold.color); } }}><span className="part-index">0{index + 1}</span><span className="part-mark">{part.id === 'battery' ? <BatteryCharging size={17} /> : part.id === 'board' ? <Cpu size={17} /> : part.id === 'cooling' ? <Flame size={17} /> : part.id === 'display' ? <Smartphone size={17} /> : part.id === 'hinge' ? <FoldHorizontal size={17} /> : part.id === 'camera' ? <Eye size={17} /> : part.id === 'coil' ? <Zap size={17} /> : part.id === 'usb' ? <Settings2 size={17} /> : <Box size={17} />}</span><span className="part-name"><b>{part.title}</b><small>{part.text}</small></span><ChevronRight size={16} className="part-arrow" /></button>)}
            </div>
            <div className="part-detail-panel">
              <div className="part-detail-top"><span className="detail-kicker">COMPONENT INSIGHT</span><span className="detail-coordinate">{selectedPart ? `PART / ${selectedPart.toUpperCase()}` : 'SELECT A COMPONENT'}</span></div>
              <div className="part-detail-art"><div className="part-art-grid" /><div className={`part-art-object ${selectedPart || 'frame'}`}><div /><i /><b /></div><span className="art-label label-left">ASSEMBLY LAYER</span><span className="art-label label-right">REFERENCE GEOMETRY</span></div>
              <h3>{partOptions.find((p) => p.id === selectedPart)?.title ?? 'A device is more than its shell.'}</h3>
              <p>{partOptions.find((p) => p.id === selectedPart)?.text ?? 'Select any component to inspect its simulated position in the 3D model. Use exploded view to separate assemblies.'}</p>
              <div className="data-confidence"><ShieldCheck size={15} /><span><b>Representation status</b><small>Illustrative model · not a verified teardown</small></span><span className="confidence-pill">SIMULATED</span></div>
              <div className="detail-actions"><button className="outline-button" onClick={() => { setExploded(true); setXray(false); scrollTo('studio') }}><Layers3 size={14} /> Isolate in 3D</button><button className="outline-button" onClick={() => { setXray(true); setExploded(false); scrollTo('studio') }}><Eye size={14} /> X-Ray mode</button></div>
            </div>
          </div>
          <div className="disclaimer-line"><ShieldCheck size={15} /><span>Internal layouts vary by model and region. Unless a verified teardown source is attached, component placement and dimensions are educational approximations.</span></div>
        </section>

        <section className="section-wrap section-block catalog-section" id="devices">
          <div className="section-heading">
            <div><div className="eyebrow"><span className="eyebrow-line" /> DEVICE INDEX / 03</div><h2>A universe of <span>form factors.</span></h2><p>Explore the icons, flagships and experiments shaping personal technology.</p></div>
            <div className="catalog-count"><b>{filteredDevices.length.toString().padStart(2, '0')}</b><span>devices in view</span></div>
          </div>
          <div className="catalog-toolbar">
            <label className="search-field"><Search size={17} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search devices, brands, chipsets..." /><kbd>⌘ K</kbd></label>
            <label className="filter-select"><Filter size={14} /><select value={brandFilter} onChange={(e) => setBrandFilter(e.target.value)}><option>All brands</option>{Array.from(new Set(devices.map((d) => d.brand))).map((brand) => <option key={brand}>{brand}</option>)}</select><ChevronDown size={13} /></label>
            <label className="filter-select"><select value={kindFilter} onChange={(e) => setKindFilter(e.target.value)}><option>All types</option><option>Flagship</option><option>Foldable</option><option>Concept</option><option>Archive</option></select><ChevronDown size={13} /></label>
            <button className={onlyConcepts ? 'filter-chip active' : 'filter-chip'} onClick={() => setOnlyConcepts(!onlyConcepts)}>{onlyConcepts ? <Check size={13} /> : <Sparkles size={13} />} Concept lab</button>
          </div>
          <div className="device-grid">
            {filteredDevices.map((device, index) => <article className="device-card" key={device.id} style={{ animationDelay: `${index * 40}ms` }}>
              <div className="device-card-top"><span className={device.kind === 'Concept' ? 'device-type concept-type' : 'device-type'}>{device.kind === 'Archive' ? 'ARCHIVE' : device.kind.toUpperCase()}</span><button aria-label="Save favorite" className={favorites.includes(device.id) ? 'favorite-button saved' : 'favorite-button'} onClick={() => toggleFavorite(device.id)}><Bookmark size={15} fill={favorites.includes(device.id) ? 'currentColor' : 'none'} /></button></div>
              <button className="device-product-visual" onClick={() => chooseDevice(device)} aria-label={`Inspect ${device.name}`}>
                <div className={`mini-phone ${device.kind === 'Foldable' ? 'mini-foldable' : ''} ${device.brand.toLowerCase().replaceAll(' ', '-')}`} style={{ '--phone-color': device.color } as CSSProperties}><div className="mini-phone-screen" /><div className="mini-camera"><i /><i /><i /></div><div className="mini-side-key" /></div>
                <span className="product-visual-orbit" />
                <span className="inspect-hint"><Move3D size={14} /> Inspect in 3D</span>
              </button>
              <div className="device-card-copy"><span className="device-brand-label">{device.brand} <span>· {device.year}</span></span><h3>{device.name}</h3><p>{device.note}</p></div>
              <div className="device-card-specs"><span><Smartphone size={13} />{device.screen}</span><span><Cpu size={13} />{device.chip.split(' ').slice(0, 2).join(' ')}</span></div>
              {device.status === 'Concept' && <div className="concept-notice">UNOFFICIAL CONCEPT · NOT A RELEASED PRODUCT</div>}
              <div className="device-card-actions"><button onClick={() => chooseDevice(device)}>Explore device <ArrowUpRight size={14} /></button><button className={compareIds.includes(device.id) ? 'compare-tick selected' : 'compare-tick'} onClick={() => toggleCompare(device.id)} title="Add to comparison"><Check size={14} /></button></div>
            </article>)}
          </div>
          {filteredDevices.length === 0 && <div className="empty-state"><Search size={24} /><b>No matching devices</b><p>Try a different model name or reset the filters.</p><button className="outline-button" onClick={() => { setSearch(''); setBrandFilter('All brands'); setKindFilter('All types'); setOnlyConcepts(false) }}>Reset filters</button></div>}
          <div className="catalog-footnote"><span><i className="live-dot" /> Catalog demonstration</span><span>Not connected to a live release feed. Check source links before relying on current launch dates or specifications.</span></div>
        </section>

        <section className="section-wrap section-block compare-section" id="compare">
          <div className="section-heading">
            <div><div className="eyebrow"><span className="eyebrow-line" /> SIDE-BY-SIDE LAB / 04</div><h2>Spec by spec. <span>Side by side.</span></h2><p>Build a comparison across up to three devices. Select models from the device index.</p></div>
            <div className="compare-quantity"><span>{compared.length}</span> / 3 selected</div>
          </div>
          <div className="compare-selector"><span>COMPARE DEVICES</span>{devices.filter((d) => d.kind !== 'Concept').slice(0, 7).map((device) => <button key={device.id} className={compareIds.includes(device.id) ? 'compare-select selected' : 'compare-select'} onClick={() => toggleCompare(device.id)}>{compareIds.includes(device.id) && <Check size={12} />}{device.name}</button>)}</div>
          <div className="compare-table-wrap"><table className="compare-table"><thead><tr><th>DEVICE PROFILE</th>{compared.map((device) => <th key={device.id}><span className="compare-mini-mark" style={{ background: device.color }} />{device.name}<small>{device.brand}</small></th>)}{compared.length === 0 && <th>Select a device above</th>}</tr></thead><tbody>
            {[
              ['Form factor', (d: Device) => d.kind], ['Display', (d: Device) => d.screen], ['Chip platform', (d: Device) => d.chip], ['Weight', (d: Device) => d.weight], ['Era / status', (d: Device) => d.year === 'Concept' ? 'Unreleased concept' : `${d.year} · released`], ['Build focus', (d: Device) => d.note], ['Internal layout', (d: Device) => d.kind === 'Foldable' ? 'Hinge + dual-cell layout (representative)' : d.kind === 'Concept' ? 'Concept only' : 'Slab layout (representative)'],
            ].map(([label, getter]) => <tr key={label as string}><td>{label as string}</td>{compared.map((device) => <td key={device.id}>{(getter as (d: Device) => string)(device)}</td>)}</tr>)}
          </tbody></table></div>
          <div className="compare-note"><span><CircleHelp size={14} /> Values shown are a front-end demo dataset; verify precise regional specifications with the manufacturer.</span><button onClick={() => { setCompareInternals(!compareInternals); setSelectedDeviceId(compareInternals ? 's25-ultra' : 'z-fold7') }}><Layers3 size={14} /> {compareInternals ? 'Hide internal comparison' : 'Compare internals'}</button></div>
          {compareInternals && <div className="internals-compare"><div><span className="internal-number">01 / {compared[0]?.brand ?? 'DEVICE A'}</span><b>{compared[0]?.name ?? 'Choose device A'}</b><div className="internal-stack"><i /><i /><i /><i /></div><small>{compared[0]?.kind === 'Foldable' ? 'Hinge, flexible display and split battery are highlighted as concepts.' : 'Slab chassis, battery and logic board shown as representative parts.'}</small></div><div><span className="internal-number">02 / {compared[1]?.brand ?? 'DEVICE B'}</span><b>{compared[1]?.name ?? 'Choose device B'}</b><div className="internal-stack alternate"><i /><i /><i /><i /></div><small>{compared[1]?.kind === 'Foldable' ? 'Hinge, flexible display and split battery are highlighted as concepts.' : 'Slab chassis, battery and logic board shown as representative parts.'}</small></div></div>}
        </section>

        <section className="section-wrap section-block os-section" id="playground">
          <div className="section-heading">
            <div><div className="eyebrow"><span className="eyebrow-line" /> SOFTWARE SANDBOX / 05</div><h2>Live inside the <span>interface.</span></h2><p>Tap around an interactive browser-based UI simulation. These are original demos, not installed mobile operating systems.</p></div>
            <span className="simulation-tag"><span className="live-dot" /> INTERACTIVE SIMULATION</span>
          </div>
          <div className="os-playground-layout">
            <div className="os-info-panel">
              <div className="control-label">CHOOSE AN EXPERIENCE <span>03 DEMOS</span></div>
              <h3>A different philosophy.<br />A different feel.</h3>
              <p>Switch between interface concepts and explore their home screens, quick settings, and sample apps.</p>
              <div className="os-choice-list">{osList.map((os, i) => <button key={os.id} className={activeOS === os.id ? 'os-choice selected' : 'os-choice'} onClick={() => { setActiveOS(os.id); setOpenApp(''); setControlPanel(false) }}><span className={`os-choice-icon ${os.id}`}>{os.id === 'ios' ? '◉' : os.id === 'oneui' ? '◈' : '✳'}</span><span><b>{os.label}</b><small>{os.brand}</small></span><span className="os-number">0{i + 1}</span><ChevronRight size={15} /></button>)}</div>
              <div className="os-info-foot"><span><ShieldCheck size={15} /> Safe, local interaction</span><span>No account needed</span></div>
            </div>
            <div className="os-demo-stage" style={{ '--os-accent': activeOSMeta.accent } as CSSProperties}>
              <div className="os-stage-orbit orbit-one" /><div className="os-stage-orbit orbit-two" />
              <div className={`os-device-frame ${osDark ? 'os-dark' : 'os-light'} ${activeOS}`}>
                <div className="os-device-bezel">
                  <div className="os-status"><span>9:41</span><span>▮▮▮ ◉ 87%</span></div>
                  <div className="os-dynamic-island" />
                  {controlPanel ? <div className="os-control-panel"><div className="control-panel-title"><span>Quick controls</span><button onClick={() => setControlPanel(false)}><X size={14} /></button></div><div className="quick-control-grid"><button className={wifi ? 'quick-tile on' : 'quick-tile'} onClick={() => setWifi(!wifi)}><span>⌁</span><b>Wi-Fi</b><small>{wifi ? 'Connected' : 'Off'}</small></button><button className={airplane ? 'quick-tile on' : 'quick-tile'} onClick={() => setAirplane(!airplane)}><span>✈</span><b>Airplane</b><small>{airplane ? 'On' : 'Off'}</small></button><button className="quick-tile on" onClick={() => setOsDark(!osDark)}><span>{osDark ? '☾' : '☼'}</span><b>Appearance</b><small>{osDark ? 'Dark' : 'Light'}</small></button><button className="quick-tile" onClick={() => setOpenApp('Settings')}><span>⚙</span><b>Settings</b><small>Open</small></button></div><div className="brightness-label">Brightness <span>72%</span></div><input aria-label="Demo brightness" type="range" min="20" max="100" defaultValue="72" /></div> : openApp ? <div className="os-app-page"><div className="os-app-top"><button onClick={() => setOpenApp('')}><ArrowLeft size={15} /></button><b>{openApp}</b><button onClick={() => setControlPanel(true)}><Settings2 size={14} /></button></div>{openApp === 'Settings' ? <><div className="os-settings-header">Settings</div>{[['Network', wifi ? 'Connected' : 'Disconnected'], ['Appearance', osDark ? 'Dark mode' : 'Light mode'], ['Battery', '87% · Simulated'], ['Privacy', 'Demo controls only']].map(([a, b]) => <button className="os-setting-row" key={a} onClick={() => a === 'Network' ? setWifi(!wifi) : a === 'Appearance' ? setOsDark(!osDark) : setOpenApp(a)}><span>{a}</span><small>{b}</small><ChevronRight size={12} /></button>)}</> : openApp === 'Camera' ? <div className="fake-camera"><div className="camera-focus">+</div><span>PHOTO · 1× · SIMULATED VIEWFINDER</span><button onClick={() => setOpenApp('Photos')}>●</button></div> : openApp === 'Photos' ? <div className="photo-demo-grid">{['#273e75', '#9f6e9e', '#507f8c', '#dfb17c', '#566080', '#58836c'].map((c, i) => <div key={c} style={{ background: `linear-gradient(${i * 35 + 120}deg, ${c}, #171a26)` }} />)}</div> : openApp === 'Browser' ? <div className="browser-demo"><div className="browser-address">⌕ Search or enter address</div><div className="browser-globe">◉</div><b>Explore the web</b><p>This is a local interface simulation. No page is loaded.</p></div> : <div className="generic-app-demo"><div className="generic-app-symbol">{appIcons.find((app) => app.name === openApp)?.glyph ?? '◌'}</div><b>{openApp}</b><p>Interactive demo screen</p><button onClick={() => setOpenApp('')}>Back to home</button></div>}</div> : <div className="os-home-screen"><div className="os-date">Friday, October 9</div><div className="os-clock">9:41</div><div className="os-widget"><span>DEVICEVERSE WEATHER</span><b>24°</b><small>Clear skies · demo data</small></div><div className="os-app-grid">{appIcons.map((app) => <button key={app.name} onClick={() => setOpenApp(app.name)}><span style={{ background: app.color }}>{app.glyph}</span><small>{app.name}</small></button>)}</div><div className="os-dock">{appIcons.slice(0, 4).map((app) => <button key={app.name} onClick={() => setOpenApp(app.name)} style={{ background: app.color }}>{app.glyph}</button>)}</div></div>}
                  <button className="os-home-bar" aria-label="Return to home" onClick={() => { setOpenApp(''); setControlPanel(false) }} />
                </div>
              </div>
              <div className="os-floating-label label-a"><span className="live-dot" /> ON-DEVICE UI SIM</div><div className="os-floating-label label-b"><Grid2X2 size={13} /> TAP ICONS TO EXPLORE</div>
              <button className="os-control-shortcut" onClick={() => { setControlPanel(!controlPanel); setOpenApp('') }}><Settings2 size={15} /> {controlPanel ? 'Close quick controls' : 'Quick controls'} <ArrowUpRight size={13} /></button>
            </div>
          </div>
          <div className="os-disclaimer"><CircleHelp size={14} /><span>Brand-inspired UI concepts are provided for exploration only. They are not official iOS, One UI or Pixel software and do not execute native apps.</span></div>
        </section>

        <section className="section-wrap lab-banner">
          <div className="lab-banner-copy"><div className="eyebrow"><span className="eyebrow-line" /> THE DEVICEVERSE VISION</div><h2>Curiosity is the<br /><span>ultimate interface.</span></h2><p>From engineering choices to the feeling of a hinge closing — discover what makes every device different.</p><button className="primary-button" onClick={() => scrollTo('devices')}>Explore the device index <ArrowRight size={16} /></button></div>
          <div className="lab-illustration"><div className="lab-ring ring-outer" /><div className="lab-ring ring-mid" /><div className="lab-core">A<span>.</span></div><div className="lab-coordinate coordinate-one">40° 43′ 18″ N</div><div className="lab-coordinate coordinate-two">01 / DEVICEVERSE</div><div className="lab-spark spark-one">✳</div><div className="lab-spark spark-two">✧</div></div>
        </section>
      </main>

      <footer className="footer section-wrap"><div className="footer-brand"><span className="brand-mark">A<span>.</span></span><div><b>AERTHENC DEVICEVERSE</b><small>Explore Every Device. Beyond the Screen.</small></div></div><div className="footer-links"><button onClick={() => scrollTo('studio')}>3D Studio</button><button onClick={() => scrollTo('inside')}>Hardware explorer</button><button onClick={() => scrollTo('playground')}>OS playground</button><button onClick={() => scrollTo('compare')}>Comparison lab</button></div><div className="footer-legal"><span>© 2026 Aerthenc Inc. · Experience prototype</span><span>Third-party brands belong to their respective owners.</span></div></footer>

      {posterOpen && <div className="modal-backdrop" role="presentation" onClick={() => setPosterOpen(false)}><div className="poster-modal" role="dialog" aria-modal="true" aria-label="Device poster preview" onClick={(e) => e.stopPropagation()}><button className="modal-close" onClick={() => setPosterOpen(false)} aria-label="Close poster"><X size={17} /></button><div className="poster-topline"><span>AERTHENC DEVICEVERSE</span><span>FIELD NOTE / 001</span></div><div className="poster-content"><div><span className="eyebrow">DEVICE STUDY · {selectedDevice.year}</span><h2>{selectedDevice.name}</h2><p>{selectedDevice.note}</p><div className="poster-specs"><span><small>DISPLAY</small><b>{selectedDevice.screen}</b></span><span><small>PLATFORM</small><b>{selectedDevice.chip}</b></span><span><small>FORM</small><b>{selectedDevice.kind}</b></span></div></div><div className="poster-device"><div className="mini-phone" style={{ '--phone-color': color } as CSSProperties}><div className="mini-phone-screen" /><div className="mini-camera"><i /><i /><i /></div></div></div></div><div className="poster-foot"><span>EXPLORE EVERY DEVICE. BEYOND THE SCREEN.</span><button className="primary-button" onClick={() => window.print()}>Print / Save PDF <ArrowUpRight size={14} /></button></div><p className="poster-note">Model visuals and component layouts are illustrative. The poster is a browser-rendered profile, not a manufacturer-authenticated product sheet.</p></div></div>}
    </div>
  )
}

export default App
