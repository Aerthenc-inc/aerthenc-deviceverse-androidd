import { useEffect, useRef, useState } from 'react'
import * as THREE from 'three'
import { OrbitControls } from 'three/addons/controls/OrbitControls.js'

type Props = {
  deviceId: string
  color: string
  exploded: boolean
  xray: boolean
  foldAngle: number
  selectedPart: string
  lowQuality: boolean
}

type PartRecord = { group: THREE.Group; base: THREE.Vector3; partId: string }

function roundedRect(width: number, height: number, radius: number) {
  const x = -width / 2
  const y = -height / 2
  const s = new THREE.Shape()
  s.moveTo(x + radius, y)
  s.lineTo(x + width - radius, y)
  s.quadraticCurveTo(x + width, y, x + width, y + radius)
  s.lineTo(x + width, y + height - radius)
  s.quadraticCurveTo(x + width, y + height, x + width - radius, y + height)
  s.lineTo(x + radius, y + height)
  s.quadraticCurveTo(x, y + height, x, y + height - radius)
  s.lineTo(x, y + radius)
  s.quadraticCurveTo(x, y, x + radius, y)
  return s
}

function roundedGeometry(width: number, height: number, depth: number, radius: number, bevel = 0.008) {
  const geometry = new THREE.ExtrudeGeometry(roundedRect(width, height, radius), {
    depth,
    bevelEnabled: bevel > 0,
    bevelSegments: 3,
    steps: 1,
    bevelSize: bevel,
    bevelThickness: bevel,
    curveSegments: 8,
  })
  geometry.translate(0, 0, -depth / 2)
  return geometry
}

function material(color: string, roughness = 0.35, metalness = 0.25) {
  return new THREE.MeshPhysicalMaterial({ color, roughness, metalness, clearcoat: 0.65, clearcoatRoughness: 0.18 })
}

function makeSphere(radius: number, color: string, z: number, metalness = 0.12) {
  const mesh = new THREE.Mesh(
    new THREE.SphereGeometry(radius, 20, 14),
    new THREE.MeshPhysicalMaterial({ color, roughness: 0.18, metalness, clearcoat: 1 }),
  )
  mesh.position.z = z
  return mesh
}

function addRounded(group: THREE.Group, id: string, width: number, height: number, depth: number, radius: number, color: string, position: [number, number, number], options: { roughness?: number; metalness?: number; bevel?: number } = {}) {
  const mesh = new THREE.Mesh(
    roundedGeometry(width, height, depth, radius, options.bevel ?? 0.006),
    material(color, options.roughness ?? 0.32, options.metalness ?? 0.28),
  )
  mesh.position.set(...position)
  mesh.userData.partId = id
  group.add(mesh)
  return mesh
}

function addPart(parent: THREE.Group, id: string, label: string, position: [number, number, number], parts: PartRecord[]) {
  const group = new THREE.Group()
  group.name = label
  group.position.set(...position)
  group.userData.partId = id
  parent.add(group)
  parts.push({ group, base: group.position.clone(), partId: id })
  return group
}

function makeDisplay(parent: THREE.Group, x: number, width: number, height: number, z: number, label: string, y = 0) {
  const display = new THREE.Group()
  display.name = label
  display.position.set(x, y, z)
  parent.add(display)
  addRounded(display, 'display', width, height, 0.012, 0.105, '#080b12', [0, 0, 0], { roughness: 0.16, metalness: 0.04, bevel: 0.002 })
  addRounded(display, 'display', width - 0.08, height - 0.10, 0.004, 0.082, '#101a2c', [0, 0, 0.009], { roughness: 0.22, metalness: 0.04, bevel: 0.001 })
  const glowA = new THREE.Mesh(new THREE.CircleGeometry(width * 0.34, 48), new THREE.MeshBasicMaterial({ color: '#384de4', transparent: true, opacity: 0.52, side: THREE.DoubleSide }))
  glowA.position.set(width * 0.12, -height * 0.08, 0.012)
  display.add(glowA)
  const glowB = new THREE.Mesh(new THREE.CircleGeometry(width * 0.26, 48), new THREE.MeshBasicMaterial({ color: '#9b55e8', transparent: true, opacity: 0.48, side: THREE.DoubleSide }))
  glowB.position.set(-width * 0.2, -height * 0.18, 0.013)
  display.add(glowB)
  const topPill = addRounded(display, 'display', width * 0.23, 0.055, 0.008, 0.027, '#03050a', [0, height * 0.43, 0.018], { roughness: 0.2, metalness: 0.03, bevel: 0.001 })
  topPill.material = new THREE.MeshPhysicalMaterial({ color: '#03050a', roughness: 0.15, metalness: 0.05 })
  for (let row = 0; row < 2; row++) {
    for (let col = 0; col < 4; col++) {
      const icon = new THREE.Mesh(
        new THREE.CircleGeometry(0.052, 18),
        new THREE.MeshBasicMaterial({ color: ['#e5e7eb', '#7f9df5', '#70d6bd', '#ed9b69'][(col + row) % 4] }),
      )
      icon.position.set((col - 1.5) * 0.19, -height * 0.22 - row * 0.18, 0.019)
      display.add(icon)
    }
  }
  const dock = addRounded(display, 'display', width * 0.78, 0.18, 0.005, 0.08, '#dfe6fa', [0, -height * 0.41, 0.017], { roughness: 0.3, metalness: 0.02, bevel: 0.001 })
  ;(dock.material as THREE.MeshPhysicalMaterial).transparent = true
  ;(dock.material as THREE.MeshPhysicalMaterial).opacity = 0.24
  return display
}

function buildPhone(root: THREE.Group, parts: PartRecord[], foldable: boolean, isFlip: boolean) {
  const bodyColor = '#777f8c'
  if (!foldable) {
    const shell = addPart(root, 'frame', 'Titanium frame', [0, 0, 0], parts)
    addRounded(shell, 'frame', 1.24, 2.56, 0.115, 0.16, bodyColor, [0, 0, 0], { metalness: 0.72, roughness: 0.25, bevel: 0.012 })
    const display = addPart(root, 'display', 'Front display', [0, 0, 0.067], parts)
    makeDisplay(display, 0, 1.16, 2.47, 0.006, 'Display glass')
    const rear = addPart(root, 'camera', 'Camera system', [0, 0, -0.077], parts)
    rear.rotation.y = Math.PI
    addRounded(rear, 'camera', 0.53, 0.94, 0.035, 0.10, '#252b35', [-0.30, 0.73, 0], { metalness: 0.55, roughness: 0.24, bevel: 0.008 })
    const lensPositions: [number, number][] = [[-0.42, 1.02], [-0.20, 1.02], [-0.42, 0.76], [-0.20, 0.76]]
    lensPositions.forEach(([x, y], index) => {
      const lens = makeSphere(index === 3 ? 0.063 : 0.074, index === 3 ? '#1c2434' : '#101722', 0.027)
      lens.position.x = x
      lens.position.y = y
      lens.userData.partId = 'camera'
      rear.add(lens)
      const lensRing = new THREE.Mesh(new THREE.TorusGeometry(index === 3 ? 0.061 : 0.072, 0.008, 8, 24), material('#a6adb8', 0.22, 0.75))
      lensRing.position.set(x, y, 0.030)
      lensRing.userData.partId = 'camera'
      rear.add(lensRing)
    })
    const flash = new THREE.Mesh(new THREE.SphereGeometry(0.037, 16, 12), new THREE.MeshBasicMaterial({ color: '#e5dfc6' }))
    flash.position.set(-0.20, 0.51, 0.027)
    flash.userData.partId = 'camera'
    rear.add(flash)
    addPart(root, 'battery', 'Battery pack', [0, -0.05, -0.18], parts)
    addRounded(parts[parts.length - 1].group, 'battery', 0.72, 1.12, 0.045, 0.065, '#a8adb4', [0.12, 0.0, 0], { metalness: 0.5, roughness: 0.42, bevel: 0.002 })
    addPart(root, 'board', 'Mainboard / SoC', [0, 0.72, -0.20], parts)
    const board = parts[parts.length - 1].group
    addRounded(board, 'board', 0.72, 0.43, 0.055, 0.04, '#1a5a4a', [-0.03, 0, 0], { metalness: 0.35, roughness: 0.42, bevel: 0.001 })
    addRounded(board, 'board', 0.22, 0.18, 0.028, 0.02, '#262b35', [0.0, 0.02, 0.037], { metalness: 0.65, roughness: 0.3, bevel: 0.001 })
    addPart(root, 'cooling', 'Vapor chamber', [0.06, -0.02, -0.25], parts)
    addRounded(parts[parts.length - 1].group, 'cooling', 0.84, 1.02, 0.018, 0.07, '#cb8e54', [-0.02, 0, 0], { metalness: 0.76, roughness: 0.3, bevel: 0.001 })
    addPart(root, 'coil', 'Wireless charging coil', [0, -0.12, -0.23], parts)
    const coil = new THREE.Mesh(new THREE.TorusGeometry(0.39, 0.022, 10, 64), material('#c5ccd5', 0.35, 0.8))
    coil.userData.partId = 'coil'
    coil.position.set(0, 0, 0)
    parts[parts.length - 1].group.add(coil)
    addPart(root, 'usb', 'USB-C and speaker module', [0, -1.22, -0.11], parts)
    addRounded(parts[parts.length - 1].group, 'usb', 0.43, 0.12, 0.045, 0.05, '#3b414b', [0, 0, 0], { metalness: 0.62, roughness: 0.3, bevel: 0.002 })
    return
  }

  if (isFlip) {
    const bottom = addPart(root, 'frame', 'Lower flip half', [0, 0, 0], parts)
    addRounded(bottom, 'frame', 1.24, 1.28, 0.105, 0.12, bodyColor, [0, -0.64, 0], { metalness: 0.7, roughness: 0.26, bevel: 0.01 })
    makeDisplay(bottom, 0, 1.16, 1.20, 0.056, 'Lower inner display', -0.64)

    const top = addPart(root, 'fold-right', 'Upper flip half', [0, 0, 0], parts)
    top.userData.foldAxis = 'x'
    addRounded(top, 'frame', 1.24, 1.28, 0.105, 0.12, bodyColor, [0, 0.64, 0], { metalness: 0.7, roughness: 0.26, bevel: 0.01 })
    makeDisplay(top, 0, 1.16, 1.20, 0.056, 'Upper inner display', 0.64)

    const hinge = addPart(root, 'hinge', 'Flip hinge mechanism', [0, 0, -0.01], parts)
    const axle = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.055, 1.10, 32), material('#969eaa', 0.23, 0.88))
    axle.rotation.z = Math.PI / 2
    axle.userData.partId = 'hinge'
    hinge.add(axle)
    for (let i = 0; i < 5; i++) {
      const band = new THREE.Mesh(new THREE.CylinderGeometry(0.065, 0.065, 0.13, 24), material('#5d6572', 0.28, 0.82))
      band.rotation.z = Math.PI / 2
      band.position.x = -0.46 + i * 0.23
      band.userData.partId = 'hinge'
      hinge.add(band)
    }

    const rear = addPart(root, 'camera', 'Cover display and camera', [0, 0, -0.12], parts)
    rear.rotation.y = Math.PI
    addRounded(rear, 'camera', 0.36, 0.61, 0.035, 0.07, '#252b35', [-0.34, 0.88, 0], { metalness: 0.58, roughness: 0.25, bevel: 0.005 })
    ;[[-0.43, 1.00], [-0.25, 1.00], [-0.34, 0.82]].forEach(([x, y]) => {
      const lens = makeSphere(0.052, '#111824', 0.028)
      lens.position.set(x, y, 0)
      lens.userData.partId = 'camera'
      rear.add(lens)
    })
    addRounded(rear, 'display', 0.48, 0.55, 0.014, 0.07, '#182338', [0.18, 0.10, 0.018], { metalness: 0.12, roughness: 0.22, bevel: 0.002 })

    addPart(root, 'battery', 'Dual battery cells', [0, 0, -0.20], parts)
    addRounded(parts[parts.length - 1].group, 'battery', 0.75, 0.52, 0.04, 0.05, '#a8adb4', [-0.03, -0.48, 0], { metalness: 0.48, roughness: 0.4, bevel: 0.001 })
    addRounded(parts[parts.length - 1].group, 'battery', 0.75, 0.52, 0.04, 0.05, '#b8bdc5', [-0.03, 0.48, 0], { metalness: 0.48, roughness: 0.4, bevel: 0.001 })
    addPart(root, 'board', 'Mainboard / SoC', [0, 0.47, -0.20], parts)
    addRounded(parts[parts.length - 1].group, 'board', 0.64, 0.34, 0.05, 0.04, '#1a5a4a', [0.22, 0, 0], { metalness: 0.35, roughness: 0.42, bevel: 0.001 })
    addPart(root, 'display', 'Flexible display stack', [0, 0, 0.20], parts)
    addRounded(parts[parts.length - 1].group, 'display', 1.18, 2.45, 0.018, 0.10, '#263d69', [0, 0, 0], { metalness: 0.14, roughness: 0.28, bevel: 0.002 })
    return
  }

  const left = addPart(root, 'frame', 'Left folding half', [-0.31, 0, 0], parts)
  addRounded(left, 'frame', 0.62, 2.56, 0.105, 0.12, bodyColor, [0, 0, 0], { metalness: 0.7, roughness: 0.26, bevel: 0.01 })
  makeDisplay(left, 0, 0.565, 2.48, 0.056, 'Left inner display')
  const right = addPart(root, 'fold-right', 'Right folding half', [0, 0, 0], parts)
  right.userData.foldRight = true
  addRounded(right, 'frame', 0.62, 2.56, 0.105, 0.12, bodyColor, [0.31, 0, 0], { metalness: 0.7, roughness: 0.26, bevel: 0.01 })
  makeDisplay(right, 0.31, 0.565, 2.48, 0.056, 'Right inner display')
  const hinge = addPart(root, 'hinge', 'Mechanical hinge', [0, 0, -0.01], parts)
  const axle = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.055, 2.36, 32), material('#969eaa', 0.23, 0.88))
  axle.rotation.x = Math.PI / 2
  axle.userData.partId = 'hinge'
  hinge.add(axle)
  for (let i = 0; i < 7; i++) {
    const band = new THREE.Mesh(new THREE.CylinderGeometry(0.065, 0.065, 0.09, 24), material('#5d6572', 0.28, 0.82))
    band.rotation.x = Math.PI / 2
    band.position.y = -1.02 + i * 0.34
    band.userData.partId = 'hinge'
    hinge.add(band)
  }
  const rearCamera = addPart(root, 'camera', 'Cover screen and camera', [0, 0, -0.12], parts)
  rearCamera.rotation.y = Math.PI
  addRounded(rearCamera, 'camera', 0.34, 0.62, 0.038, 0.07, '#252b35', [0.43, 0.82, 0], { metalness: 0.58, roughness: 0.25, bevel: 0.005 })
  ;[0.96, 0.70].forEach((y) => {
    const lens = makeSphere(0.068, '#111824', 0.025)
    lens.position.set(0.43, y, 0)
    lens.userData.partId = 'camera'
    rearCamera.add(lens)
  })
  addPart(root, 'battery', 'Dual battery cells', [0, -0.04, -0.20], parts)
  addRounded(parts[parts.length - 1].group, 'battery', 0.47, 1.08, 0.04, 0.05, '#a8adb4', [-0.31, 0, 0], { metalness: 0.48, roughness: 0.4, bevel: 0.001 })
  addRounded(parts[parts.length - 1].group, 'battery', 0.47, 1.08, 0.04, 0.05, '#b8bdc5', [0.31, 0, 0], { metalness: 0.48, roughness: 0.4, bevel: 0.001 })
  addPart(root, 'board', 'Mainboard / SoC', [0, 0.86, -0.20], parts)
  addRounded(parts[parts.length - 1].group, 'board', 0.49, 0.34, 0.05, 0.04, '#1a5a4a', [0.30, 0, 0], { metalness: 0.35, roughness: 0.42, bevel: 0.001 })
  addPart(root, 'display', 'Flexible display stack', [0, 0, 0.20], parts)
  addRounded(parts[parts.length - 1].group, 'display', 1.18, 2.45, 0.018, 0.10, '#263d69', [0, 0, 0], { metalness: 0.14, roughness: 0.28, bevel: 0.002 })
}

export default function DeviceViewer({ deviceId, color, exploded, xray, foldAngle, selectedPart, lowQuality }: Props) {
  const hostRef = useRef<HTMLDivElement | null>(null)
  const sceneState = useRef<{ renderer: THREE.WebGLRenderer; controls: OrbitControls; root: THREE.Group; parts: PartRecord[]; foldRight?: THREE.Group } | null>(null)
  const [error, setError] = useState('')
  const foldable = deviceId.toLowerCase().includes('fold') || deviceId.toLowerCase().includes('flip') || deviceId.toLowerCase().includes('duo') || deviceId.toLowerCase().includes('razr')
  const isFlip = deviceId.toLowerCase().includes('flip') || deviceId.toLowerCase().includes('razr')

  useEffect(() => {
    const host = hostRef.current
    if (!host) return
    let renderer: THREE.WebGLRenderer
    try {
      const scene = new THREE.Scene()
      scene.background = new THREE.Color('#0a0b12')
      scene.fog = new THREE.Fog('#0a0b12', 7.5, 15)
      const camera = new THREE.PerspectiveCamera(34, host.clientWidth / Math.max(host.clientHeight, 1), 0.1, 100)
      camera.position.set(3.15, 1.7, 4.7)
      camera.lookAt(0, 0, 0)
      renderer = new THREE.WebGLRenderer({ antialias: !lowQuality, alpha: false, powerPreference: lowQuality ? 'low-power' : 'high-performance' })
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, lowQuality ? 1 : 1.7))
      renderer.setSize(host.clientWidth, host.clientHeight)
      renderer.outputColorSpace = THREE.SRGBColorSpace
      renderer.toneMapping = THREE.ACESFilmicToneMapping
      renderer.toneMappingExposure = 1.1
      host.replaceChildren(renderer.domElement)

      scene.add(new THREE.HemisphereLight('#dce7ff', '#15121f', 2.0))
      const key = new THREE.DirectionalLight('#fff2df', 3.5)
      key.position.set(3, 4, 4)
      scene.add(key)
      const rim = new THREE.PointLight('#8874ff', 15, 12)
      rim.position.set(-3, 1.5, -2)
      scene.add(rim)
      const blue = new THREE.PointLight('#3d8cff', 11, 10)
      blue.position.set(2, -1, 2)
      scene.add(blue)

      const grid = new THREE.GridHelper(10, 32, '#343450', '#1b1c2b')
      grid.position.y = -1.58
      ;(grid.material as THREE.Material).transparent = true
      ;(grid.material as THREE.Material).opacity = 0.38
      scene.add(grid)
      const ring = new THREE.Mesh(new THREE.TorusGeometry(1.45, 0.008, 8, 128), new THREE.MeshBasicMaterial({ color: '#6654cc', transparent: true, opacity: 0.45 }))
      ring.rotation.x = Math.PI / 2.9
      ring.position.y = -0.1
      scene.add(ring)

      const root = new THREE.Group()
      scene.add(root)
      const parts: PartRecord[] = []
      buildPhone(root, parts, foldable, isFlip)
      const controls = new OrbitControls(camera, renderer.domElement)
      controls.enableDamping = true
      controls.dampingFactor = 0.055
      controls.minDistance = 3.0
      controls.maxDistance = 8.0
      controls.enablePan = false
      controls.target.set(0, 0, 0)

      sceneState.current = { renderer, controls, root, parts, foldRight: parts.find((p) => p.partId === 'fold-right')?.group }
      setError('')
      let frame = 0
      let running = true
      const animate = () => {
        if (!running) return
        frame = requestAnimationFrame(animate)
        controls.update()
        renderer.render(scene, camera)
      }
      animate()
      const onResize = () => {
        if (!host.isConnected) return
        camera.aspect = host.clientWidth / Math.max(host.clientHeight, 1)
        camera.updateProjectionMatrix()
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, lowQuality ? 1 : 1.7))
        renderer.setSize(host.clientWidth, host.clientHeight)
      }
      const observer = new ResizeObserver(onResize)
      observer.observe(host)
      return () => {
        running = false
        cancelAnimationFrame(frame)
        observer.disconnect()
        controls.dispose()
        scene.traverse((object) => {
          if (object instanceof THREE.Mesh) {
            object.geometry.dispose()
            const mats = Array.isArray(object.material) ? object.material : [object.material]
            mats.forEach((m) => m.dispose())
          }
        })
        renderer.dispose()
        host.replaceChildren()
        sceneState.current = null
      }
    } catch (e) {
      setError('WebGL açılamadı. Cihazın tarayıcısında donanım hızlandırmayı etkinleştir veya masaüstünde dene.')
      console.error(e)
    }
  }, [deviceId, foldable, isFlip, lowQuality])

  useEffect(() => {
    const state = sceneState.current
    if (!state) return
    const hex = color || '#777f8c'
    state.parts.forEach(({ group, base, partId }) => {
      group.position.copy(base)
      const offset = exploded ? ({ frame: 0.36, display: 0.56, camera: -0.30, battery: -0.46, board: -0.25, cooling: -0.62, coil: -0.38, usb: -0.50, hinge: -0.05, 'fold-right': 0.05 } as Record<string, number>)[partId] ?? 0 : 0
      group.position.z += offset
      if (partId === 'fold-right') {
        const angle = THREE.MathUtils.degToRad(foldAngle)
        if (group.userData.foldAxis === 'x') group.rotation.x = angle
        else group.rotation.y = -angle
      }
      group.traverse((object) => {
        if (!(object instanceof THREE.Mesh)) return
        const mats = Array.isArray(object.material) ? object.material : [object.material]
        mats.forEach((mat) => {
          if (!(mat instanceof THREE.MeshStandardMaterial || mat instanceof THREE.MeshPhysicalMaterial)) return
          if (object.userData.partId === 'frame' && mat.color) mat.color.set(hex)
          if (object.userData.partId === selectedPart) {
            mat.emissive?.set('#6554e8')
            if (mat.emissiveIntensity !== undefined) mat.emissiveIntensity = 0.42
          } else {
            mat.emissive?.set('#000000')
            if (mat.emissiveIntensity !== undefined) mat.emissiveIntensity = 0
          }
          if (object.userData.partId === 'frame' || object.userData.partId === 'display') {
            mat.transparent = xray
            mat.opacity = xray ? (object.userData.partId === 'frame' ? 0.20 : 0.24) : 1
            mat.depthWrite = !xray
          }
        })
      })
    })
  }, [color, exploded, xray, foldAngle, selectedPart])

  return (
    <div className="viewer-shell">
      <div className="viewer-canvas" ref={hostRef} aria-label="Interactive 3D phone model" />
      {error && <div className="viewer-error">{error}</div>}
      <div className="viewer-hud"><span><i className="live-dot" /> INTERACTIVE 3D</span><span>DRAG TO ROTATE · SCROLL TO ZOOM</span></div>
      <div className="viewer-axis"><span>X</span><span>Y</span><span>Z</span></div>
    </div>
  )
}
