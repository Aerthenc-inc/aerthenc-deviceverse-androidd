#!/usr/bin/env bash
set -euo pipefail

# Run from the project root on a computer with Node.js, Android Studio,
# Android SDK and a compatible JDK installed.
npm install
npm run build
if [ ! -d android ]; then
  npx cap add android
fi
npx cap sync android
npx cap open android
