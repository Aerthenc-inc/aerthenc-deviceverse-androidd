# Aerthenc DeviceVerse

**Explore Every Device. Beyond the Screen.**

An interactive front-end prototype for Aerthenc Inc. It includes a real WebGL/Three.js device viewer with generated 3D geometry, fold-angle controls for a representative book-style foldable model, an exploded-components/X-ray interface, a searchable sample device catalog, side-by-side specifications, and three browser-only OS-inspired UI demos.

## Run locally

Requirements: Node.js 20+ recommended.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite. To make a production build:

```bash
npm run build
npm run preview
```

## Important accuracy notes

- The main phone models are procedurally generated 3D geometry, not official manufacturer CAD assets or exact photogrammetry.
- Internal component placements are educational representations, not verified teardowns.
- The iOS, One UI and Pixel-style experiences are original browser UI simulations, not native operating systems or official manufacturer software.
- The catalog is a static demonstration dataset. It is not connected to a live announcements, price, specification, or source feed. Confirm current data with manufacturers before publication.
- This project uses Three.js via npm. The 3D viewer requires WebGL; if unavailable, it shows a fallback explanation.
- Google Fonts are loaded externally when the browser has a network connection; the app otherwise uses fallback fonts.

## Included interactions

- 3D drag-to-rotate and scroll/pinch zoom (OrbitControls)
- Finish color switching, low-power render mode, exploded view, X-Ray shell, assembly reset
- Fold angle slider and presets on foldable reference models
- Component selection and highlighting
- Device search and brand/type filters, favorites (session state), concept-only filter
- Compare up to 3 devices, representative internals comparison
- Tap-through OS demo icons, Settings, Camera, Photos, Browser, quick controls, Wi-Fi/airplane and light/dark toggles
- Device poster preview and browser print / Save to PDF
- Dark/light platform theme, responsive layouts, reduced-motion CSS preference

## Project structure

```text
src/
  App.tsx          Main experience and all front-end interactions
  DeviceViewer.tsx Three.js scene and procedural model geometry
  main.tsx         React entry point
  styles.css       Responsive visual system and motion
```
