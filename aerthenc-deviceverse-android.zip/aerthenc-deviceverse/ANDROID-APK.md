# Aerthenc DeviceVerse — Android APK

This project is prepared to be wrapped as a native Android app with Capacitor. It includes the React/Three.js source and the Capacitor configuration; the generated Android Studio project and APK are not included yet because this build environment does not have the Android SDK/Gradle toolchain installed and dependency installation could not be completed here.

## Requirements
- Node.js 20+
- Android Studio with Android SDK installed
- A compatible JDK (use the version recommended by your installed Android Gradle Plugin/Android Studio)
- Internet access for npm package installation on the first build

## Build the Android app
1. Extract the ZIP.
2. Open a terminal in the `aerthenc-deviceverse` folder.
3. Run `./build-android.sh` (macOS/Linux) or follow the manual commands below on Windows.
4. Android Studio opens the generated `android` project. Wait for Gradle sync to finish.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The debug APK is usually written to `android/app/build/outputs/apk/debug/app-debug.apk`.

### Manual commands (Windows PowerShell or any terminal)
```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

If an `android` folder already exists, skip `npx cap add android` and run `npx cap sync android` instead.

## Phone-specific notes
- The UI has responsive layouts and touch-friendly interactions; the 3D viewer uses Three.js/WebGL.
- On mid-range phones such as the Samsung Galaxy A32, use the viewer's low-power/low-detail option if frame rate drops, close other heavy apps, and avoid running multiple 3D views simultaneously.
- The first build needs internet to download npm and Android dependencies. Once bundled, the main UI assets are packaged in the app; any externally loaded fonts still require internet.
- This is a native Android WebView shell around the web app, not a fully native 3D renderer. Device geometry and internals remain educational procedural models rather than manufacturer CAD assets.
